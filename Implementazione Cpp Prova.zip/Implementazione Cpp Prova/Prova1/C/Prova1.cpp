#include "Prova1.h"
#include <map>
#include <iostream>
#include <cmath>

// Storage statico per le temperature
static std::map<int, double> temperatureStorage;
static int nextIndex = 0;

extern "C" {
    
int createTemperatureSlot() {
    int index = nextIndex++;
    temperatureStorage[index] = 20.0; // Default: 20°C
    std::cout << "[C++] Created temperature slot with index: " << index << std::endl;
    return index;
}

void setTemperature(int index, double temperature) {
    if (temperatureStorage.find(index) == temperatureStorage.end()) {
        std::cerr << "[C++] Warning: Setting temperature for non-existent index " 
                  << index << std::endl;
        temperatureStorage[index] = temperature;
    } else {
        temperatureStorage[index] = temperature;
    }
    std::cout << "[C++] Set temperature at index " << index 
              << " = " << temperature << "°C" << std::endl;
}

double getTemperature(int index) {
    if (temperatureStorage.find(index) == temperatureStorage.end()) {
        std::cerr << "[C++] Error: Getting temperature for non-existent index " 
                  << index << std::endl;
        return 0.0;
    }
    return temperatureStorage[index];
}

int mixTemperatures(int index1, int index2) {
    double temp1 = getTemperature(index1);
    double temp2 = getTemperature(index2);
    
    // Media semplice delle due temperature
    double mixedTemp = 0.5 * (temp1 + temp2);
    
    // Crea un nuovo slot per la temperatura miscelata
    int resultIndex = createTemperatureSlot();
    temperatureStorage[resultIndex] = mixedTemp;
    
    std::cout << "[C++] Mixed temperatures: " << temp1 << "°C + " << temp2 
              << "°C = " << mixedTemp << "°C at index " << resultIndex << std::endl;
    
    return resultIndex;
}

void clearAllTemperatures() {
    std::cout << "[C++] Clearing all temperature slots" << std::endl;
    temperatureStorage.clear();
    nextIndex = 0;
}

void printAllTemperatures() {
    std::cout << "[C++] === Temperature Storage Status ===" << std::endl;
    for (const auto& pair : temperatureStorage) {
        std::cout << "  Index " << pair.first << ": " << pair.second << "°C" << std::endl;
    }
    std::cout << "[C++] ===================================" << std::endl;
}

} // extern "C"
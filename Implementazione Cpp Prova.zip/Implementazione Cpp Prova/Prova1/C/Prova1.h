#ifndef TEMPERATURE_STORAGE_H
#define TEMPERATURE_STORAGE_H

#ifdef __cplusplus
extern "C" {
#endif

// Crea un nuovo slot per temperatura e ritorna l'indice
int createTemperatureSlot();

// Imposta la temperatura per un dato indice
void setTemperature(int index, double temperature);

// Leggi la temperatura da un dato indice
double getTemperature(int index);

// Calcola il mixing di due temperature (senza portate)
int mixTemperatures(int index1, int index2);

// Funzione di cleanup (opzionale, per deallocare)
void clearAllTemperatures();

// Debug: stampa tutti i valori
void printAllTemperatures();

#ifdef __cplusplus
}
#endif

#endif // TEMPERATURE_STORAGE_H
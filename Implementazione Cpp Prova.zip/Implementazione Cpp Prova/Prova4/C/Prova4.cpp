#include "Prova4.h"
#include <map>
#include <string>
#include <vector>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <cmath>

//==============================================================================
// STORAGE GLOBALI
//==============================================================================
static std::map<int, double> temperatureStorage;
static std::map<int, double> flowRateStorage;
static std::map<int, double> pressureStorage;

// Storage per composizioni (frazioni massiche percentuali)
struct CompositionData {
    std::vector<std::string> componentNames;
    std::vector<double> massFractions;  // [%] somma deve essere 100
};
static std::map<int, CompositionData> compositionStorage;

static int nextTempIndex = 0;
static int nextFlowIndex = 0;
static int nextPressIndex = 0;
static int nextCompIndex = 0;

//==============================================================================
// IMPLEMENTAZIONE FUNZIONI
//==============================================================================

extern "C" {

//------------------------------------------------------------------------------
// TEMPERATURE
//------------------------------------------------------------------------------

int createTemperatureSlot() {
    int index = nextTempIndex++;
    temperatureStorage[index] = 20.0;
    std::cout << "[C++] Created temperature slot: " << index << std::endl;
    return index;
}

void setTemperature(int index, double temperature) {
    temperatureStorage[index] = temperature;
}

double getTemperature(int index) {
    if (temperatureStorage.find(index) == temperatureStorage.end()) {
        std::cerr << "[C++] Error: Temperature index " << index << " not found!" << std::endl;
        return 0.0;
    }
    return temperatureStorage[index];
}

//------------------------------------------------------------------------------
// FLOW RATES
//------------------------------------------------------------------------------

int createFlowRateSlot() {
    int index = nextFlowIndex++;
    flowRateStorage[index] = 0.0;
    std::cout << "[C++] Created flow rate slot: " << index << std::endl;
    return index;
}

void setFlowRate(int index, double flowRate) {
    flowRateStorage[index] = flowRate;
}

double getFlowRate(int index) {
    if (flowRateStorage.find(index) == flowRateStorage.end()) {
        std::cerr << "[C++] Error: Flow rate index " << index << " not found!" << std::endl;
        return 0.0;
    }
    return flowRateStorage[index];
}

//------------------------------------------------------------------------------
// PRESSURES
//------------------------------------------------------------------------------

int createPressureSlot() {
    int index = nextPressIndex++;
    pressureStorage[index] = 101325.0;
    std::cout << "[C++] Created pressure slot: " << index << std::endl;
    return index;
}

void setPressure(int index, double pressure) {
    pressureStorage[index] = pressure;
}

double getPressure(int index) {
    if (pressureStorage.find(index) == pressureStorage.end()) {
        std::cerr << "[C++] Error: Pressure index " << index << " not found!" << std::endl;
        return 0.0;
    }
    return pressureStorage[index];
}

//------------------------------------------------------------------------------
// COMPOSITIONS (MASS FRACTIONS PERCENTUALI)
//------------------------------------------------------------------------------

int createCompositionSlot() {
    int index = nextCompIndex++;
    compositionStorage[index] = CompositionData();
    std::cout << "[C++] Created composition slot: " << index << std::endl;
    return index;
}

int setComposition(int index, const char** names, const double* fractions, int nComponents) {
    CompositionData& comp = compositionStorage[index];
    comp.componentNames.clear();
    comp.massFractions.clear();
    
    // Calcola la somma delle frazioni
    double sum = 0.0;
    for (int i = 0; i < nComponents; i++) {
        sum += fractions[i];
    }
    
    // VALIDAZIONE: Verifica che la somma sia circa 100%
    const double TOLERANCE = 0.01;  // Tolleranza 0.01%
    if (std::abs(sum - 100.0) > TOLERANCE) {
        std::cerr << "[C++] ERROR: Mass fractions do not sum to 100%!" << std::endl;
        std::cerr << "[C++]   Expected: 100.0%" << std::endl;
        std::cerr << "[C++]   Got:      " << sum << "%" << std::endl;
        std::cerr << "[C++]   Components: ";
        for (int i = 0; i < nComponents; i++) {
            std::cerr << names[i] << "=" << fractions[i] << "% ";
        }
        std::cerr << std::endl;
        return -1;  // Errore
    }
    
    // Tutto OK, salva i dati
    for (int i = 0; i < nComponents; i++) {
        comp.componentNames.push_back(std::string(names[i]));
        comp.massFractions.push_back(fractions[i]);
    }
    
    std::cout << "[C++] Set composition[" << index << "] with " << nComponents 
              << " components (total: " << sum << "%): ";
    for (int i = 0; i < nComponents; i++) {
        std::cout << names[i] << "=" << fractions[i] << "%";
        if (i < nComponents - 1) std::cout << ", ";
    }
    std::cout << std::endl;
    
    return 0;  // Successo
}

int mixCompositions(int idx1, double flowRate1, int idx2, double flowRate2) {
    if (compositionStorage.find(idx1) == compositionStorage.end() ||
        compositionStorage.find(idx2) == compositionStorage.end()) {
        std::cerr << "[C++] Error: Invalid composition indices for mixing!" << std::endl;
        return -1;
    }
    
    CompositionData& comp1 = compositionStorage[idx1];
    CompositionData& comp2 = compositionStorage[idx2];
    
    std::cout << "\n[C++] ========== MIXING COMPOSITIONS (Mass Fractions %) ==========" << std::endl;
    std::cout << "[C++] Stream 1 (m=" << flowRate1 << " kg/s): ";
    for (size_t i = 0; i < comp1.componentNames.size(); i++) {
        std::cout << comp1.componentNames[i] << "=" << comp1.massFractions[i] << "% ";
    }
    std::cout << std::endl;
    
    std::cout << "[C++] Stream 2 (m=" << flowRate2 << " kg/s): ";
    for (size_t i = 0; i < comp2.componentNames.size(); i++) {
        std::cout << comp2.componentNames[i] << "=" << comp2.massFractions[i] << "% ";
    }
    std::cout << std::endl;
    
    // Calcola i pesi
    double totalFlow = flowRate1 + flowRate2;
    double w1, w2;
    
    if (totalFlow < 1e-10) {
        std::cout << "[C++] Note: Total flow rate very small (" << totalFlow 
                  << "), using equal weights (0.5, 0.5)" << std::endl;
        w1 = 0.5;
        w2 = 0.5;
    } else {
        w1 = flowRate1 / totalFlow;
        w2 = flowRate2 / totalFlow;
        std::cout << "[C++] Weights: w1=" << w1 << " (" << w1*100 << "%), w2=" 
                  << w2 << " (" << w2*100 << "%)" << std::endl;
    }
    
    // Usa std::map per unire i componenti automaticamente (ordine alfabetico)
    std::map<std::string, double> mixedFractions;
    
    // Aggiungi componenti dal primo stream (pesati)
    for (size_t i = 0; i < comp1.componentNames.size(); i++) {
        std::string name = comp1.componentNames[i];
        double fraction = comp1.massFractions[i] * w1;
        mixedFractions[name] = fraction;
    }
    
    // Aggiungi/somma componenti dal secondo stream (pesati)
    for (size_t i = 0; i < comp2.componentNames.size(); i++) {
        std::string name = comp2.componentNames[i];
        double fraction = comp2.massFractions[i] * w2;
        
        if (mixedFractions.find(name) != mixedFractions.end()) {
            // Componente già presente: somma le frazioni
            mixedFractions[name] += fraction;
        } else {
            // Nuovo componente
            mixedFractions[name] = fraction;
        }
    }
    
    // Verifica che la somma sia 100%
    double totalFraction = 0.0;
    for (const auto& pair : mixedFractions) {
        totalFraction += pair.second;
    }
    
    std::cout << "[C++] Total mass fraction after mixing: " << totalFraction << "%" << std::endl;
    
    // Normalizzazione se necessaria (errori di arrotondamento)
    if (std::abs(totalFraction - 100.0) > 0.01 && totalFraction > 0.0) {
        std::cout << "[C++] Normalizing to exactly 100%..." << std::endl;
        double normFactor = 100.0 / totalFraction;
        for (auto& pair : mixedFractions) {
            pair.second *= normFactor;
        }
        totalFraction = 100.0;
    }
    
    // Crea la nuova composizione miscelata
    int resultIndex = createCompositionSlot();
    CompositionData& resultComp = compositionStorage[resultIndex];
    
    // std::map ordina automaticamente le chiavi alfabeticamente
    for (const auto& pair : mixedFractions) {
        resultComp.componentNames.push_back(pair.first);
        resultComp.massFractions.push_back(pair.second);
    }
    
    std::cout << "[C++] Mixed result (index=" << resultIndex << ", total=" 
              << totalFraction << "%): ";
    for (size_t i = 0; i < resultComp.componentNames.size(); i++) {
        std::cout << resultComp.componentNames[i] << "=" 
                  << resultComp.massFractions[i] << "%";
        if (i < resultComp.componentNames.size() - 1) std::cout << ", ";
    }
    std::cout << std::endl;
    std::cout << "[C++] ================================================================\n" << std::endl;
    
    return resultIndex;
}

int getNumberOfComponents(int index) {
    if (compositionStorage.find(index) == compositionStorage.end()) {
        std::cerr << "[C++] Error: Composition index " << index << " not found!" << std::endl;
        return 0;
    }
    
    CompositionData& comp = compositionStorage[index];
    return comp.componentNames.size();
}

double getComponentMassFraction(int index, int componentIdx) {
    if (compositionStorage.find(index) == compositionStorage.end()) {
        std::cerr << "[C++] Error: Composition index " << index << " not found!" << std::endl;
        return 0.0;
    }
    
    CompositionData& comp = compositionStorage[index];
    
    if (componentIdx < 0 || componentIdx >= (int)comp.massFractions.size()) {
        std::cerr << "[C++] Error: Component index " << componentIdx 
                  << " out of range (0-" << comp.massFractions.size()-1 
                  << ") for composition " << index << std::endl;
        return 0.0;
    }
    
    return comp.massFractions[componentIdx];
}

double getComponentMassFractionByName(int index, const char* componentName) {
    if (compositionStorage.find(index) == compositionStorage.end()) {
        std::cerr << "[C++] Error: Composition index " << index << " not found!" << std::endl;
        return 0.0;
    }
    
    CompositionData& comp = compositionStorage[index];
    std::string searchName(componentName);
    
    for (size_t i = 0; i < comp.componentNames.size(); i++) {
        if (comp.componentNames[i] == searchName) {
            return comp.massFractions[i];
        }
    }
    
    // Componente non trovato - ritorna 0 (non è un errore)
    return 0.0;
}

int hasComponent(int index, const char* componentName) {
    if (compositionStorage.find(index) == compositionStorage.end()) {
        return 0;  // false
    }
    
    CompositionData& comp = compositionStorage[index];
    std::string searchName(componentName);
    
    for (size_t i = 0; i < comp.componentNames.size(); i++) {
        if (comp.componentNames[i] == searchName) {
            return 1;  // true
        }
    }
    
    return 0;  // false
}

double getTotalMassFraction(int index) {
    if (compositionStorage.find(index) == compositionStorage.end()) {
        std::cerr << "[C++] Error: Composition index " << index << " not found!" << std::endl;
        return 0.0;
    }
    
    CompositionData& comp = compositionStorage[index];
    double sum = 0.0;
    for (double fraction : comp.massFractions) {
        sum += fraction;
    }
    return sum;
}

void printComposition(int index) {
    if (compositionStorage.find(index) == compositionStorage.end()) {
        std::cout << "[C++] Composition[" << index << "]: <not found>" << std::endl;
        return;
    }
    
    CompositionData& comp = compositionStorage[index];
    double total = getTotalMassFraction(index);
    
    std::cout << "[C++] Composition[" << index << "] (total: " << total << "%):" << std::endl;
    for (size_t i = 0; i < comp.componentNames.size(); i++) {
        std::cout << "  " << comp.componentNames[i] << " = " 
                  << comp.massFractions[i] << " %" << std::endl;
    }
}

void printCompositionCompact(int index) {
    if (compositionStorage.find(index) == compositionStorage.end()) {
        std::cout << "[C++] Comp[" << index << "]: <empty>" << std::endl;
        return;
    }
    
    CompositionData& comp = compositionStorage[index];
    double total = getTotalMassFraction(index);
    
    std::cout << "[C++] Comp[" << index << "] (" << comp.componentNames.size() 
              << " components, total: " << total << "%): ";
    
    for (size_t i = 0; i < comp.componentNames.size(); i++) {
        std::cout << comp.componentNames[i] << "=" << comp.massFractions[i] << "%";
        if (i < comp.componentNames.size() - 1) {
            std::cout << ", ";
        }
    }
    std::cout << std::endl;
}

void freeComposition(int index) {
    compositionStorage.erase(index);
}

//------------------------------------------------------------------------------
// UTILITY
//------------------------------------------------------------------------------

void clearAllStorage() {
    temperatureStorage.clear();
    flowRateStorage.clear();
    pressureStorage.clear();
    compositionStorage.clear();
    nextTempIndex = 0;
    nextFlowIndex = 0;
    nextPressIndex = 0;
    nextCompIndex = 0;
    std::cout << "[C++] Cleared all storage" << std::endl;
}

void printAllTemperatures() {
    std::cout << "[C++] === TEMPERATURES ===" << std::endl;
    for (const auto& pair : temperatureStorage) {
        std::cout << "  T[" << pair.first << "] = " << pair.second << "°C" << std::endl;
    }
}

void printAllFlowRates() {
    std::cout << "[C++] === FLOW RATES ===" << std::endl;
    for (const auto& pair : flowRateStorage) {
        std::cout << "  m[" << pair.first << "] = " << pair.second << " kg/s" << std::endl;
    }
}

void printAllPressures() {
    std::cout << "[C++] === PRESSURES ===" << std::endl;
    for (const auto& pair : pressureStorage) {
        std::cout << "  P[" << pair.first << "] = " << pair.second/1000.0 << " kPa" << std::endl;
    }
}

void printAllCompositions() {
    std::cout << "[C++] === COMPOSITIONS (Mass Fractions) ===" << std::endl;
    for (const auto& pair : compositionStorage) {
        std::cout << "  Comp[" << pair.first << "]: ";
        const CompositionData& comp = pair.second;
        double total = 0.0;
        for (size_t i = 0; i < comp.componentNames.size(); i++) {
            std::cout << comp.componentNames[i] << "=" << comp.massFractions[i] << "%";
            total += comp.massFractions[i];
            if (i < comp.componentNames.size() - 1) std::cout << ", ";
        }
        std::cout << " (total: " << total << "%)" << std::endl;
    }
}

void printFluidState(int tempIdx, int flowIdx, int pressIdx) {
    std::cout << "[C++] === FLUID STATE ===" << std::endl;
    std::cout << "  Temperature: T[" << tempIdx << "] = " << getTemperature(tempIdx) << " °C" << std::endl;
    std::cout << "  Flow rate:   m[" << flowIdx << "] = " << getFlowRate(flowIdx) << " kg/s" << std::endl;
    std::cout << "  Pressure:    P[" << pressIdx << "] = " << getPressure(pressIdx)/1000.0 << " kPa" << std::endl;
    std::cout << "[C++] ====================" << std::endl;
}

} // extern "C"
#ifndef PROVA3_H
#define PROVA3_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

//==============================================================================
// GESTIONE TEMPERATURE
//==============================================================================
int createTemperatureSlot();
void setTemperature(int index, double temperature);
double getTemperature(int index);

//==============================================================================
// GESTIONE PORTATE
//==============================================================================
int createFlowRateSlot();
void setFlowRate(int index, double flowRate);
double getFlowRate(int index);

//==============================================================================
// GESTIONE PRESSIONI
//==============================================================================
int createPressureSlot();
void setPressure(int index, double pressure);
double getPressure(int index);

//==============================================================================
// GESTIONE COMPOSIZIONI (FRAZIONI MASSICHE PERCENTUALI)
//==============================================================================

typedef struct {
    char** componentNames;
    double* massFractions;  // Frazioni massiche [%]
    int nComponents;
} Composition;

// Creazione e impostazione
int createCompositionSlot();

// Imposta composizione con VALIDAZIONE (somma deve essere 100%)
int setComposition(int index, const char** names, const double* fractions, int nComponents);

// Mixing (restituisce frazioni che sommano a 100%)
int mixCompositions(int idx1, double flowRate1, int idx2, double flowRate2);

// Lettura
int getNumberOfComponents(int index);
double getComponentMassFraction(int index, int componentIdx);
double getComponentMassFractionByName(int index, const char* componentName);
int hasComponent(int index, const char* componentName);

// Verifica che le frazioni sommino a 100%
double getTotalMassFraction(int index);

// Stampa
void printComposition(int index);
void printCompositionCompact(int index);

// Pulizia
void freeComposition(int index);

//==============================================================================
// UTILITY
//==============================================================================
void clearAllStorage();
void printAllTemperatures();
void printAllFlowRates();
void printAllPressures();
void printAllCompositions();
void printFluidState(int tempIdx, int flowIdx, int pressIdx);

#ifdef __cplusplus
}
#endif

#endif // PROVA3_H
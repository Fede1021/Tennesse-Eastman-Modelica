#include "Prova2.h"
#include <map>
#include <iostream>
#include <cmath>
#include <algorithm>

//==============================================================================
// STORAGE GLOBALI
//==============================================================================
static std::map<int, double> temperatureStorage;
static std::map<int, double> flowRateStorage;
static std::map<int, double> pressureStorage;

static int nextTempIndex = 0;
static int nextFlowIndex = 0;
static int nextPressIndex = 0;

//==============================================================================
// TEMPERATURE
//==============================================================================
extern "C" {

int createTemperatureSlot() {
    int index = nextTempIndex++;
    temperatureStorage[index] = 20.0; // Default: 20°C
    std::cout << "[C++] Created temperature slot: " << index << std::endl;
    return index;
}

void setTemperature(int index, double temperature) {
    temperatureStorage[index] = temperature;
    // Commenta questa riga se produce troppo output
    // std::cout << "[C++] Set T[" << index << "] = " << temperature << "°C" << std::endl;
}

double getTemperature(int index) {
    if (temperatureStorage.find(index) == temperatureStorage.end()) {
        std::cerr << "[C++] Error: Temperature index " << index << " not found!" << std::endl;
        return 0.0;
    }
    return temperatureStorage[index];
}

int mixTemperatures(int idx1, int idx2) {
    double temp1 = getTemperature(idx1);
    double temp2 = getTemperature(idx2);
    double mixedTemp = 0.5 * (temp1 + temp2);
    
    int resultIndex = createTemperatureSlot();
    temperatureStorage[resultIndex] = mixedTemp;
    
    std::cout << "[C++] Mixed temps: " << temp1 << " + " << temp2 
              << " = " << mixedTemp << " at index " << resultIndex << std::endl;
    return resultIndex;
}

//==============================================================================
// FLOW RATES
//==============================================================================

int createFlowRateSlot() {
    int index = nextFlowIndex++;
    flowRateStorage[index] = 0.0; // Default: 0 kg/s
    std::cout << "[C++] Created flow rate slot: " << index << std::endl;
    return index;
}

void setFlowRate(int index, double flowRate) {
    flowRateStorage[index] = flowRate;
    // Commenta se produce troppo output
    // std::cout << "[C++] Set m_flow[" << index << "] = " << flowRate << " kg/s" << std::endl;
}

double getFlowRate(int index) {
    if (flowRateStorage.find(index) == flowRateStorage.end()) {
        std::cerr << "[C++] Error: Flow rate index " << index << " not found!" << std::endl;
        return 0.0;
    }
    return flowRateStorage[index];
}

int sumFlowRates(int idx1, int idx2) {
    double flow1 = getFlowRate(idx1);
    double flow2 = getFlowRate(idx2);
    double totalFlow = flow1 + flow2;
    
    int resultIndex = createFlowRateSlot();
    flowRateStorage[resultIndex] = totalFlow;
    
    std::cout << "[C++] Summed flows: " << flow1 << " + " << flow2 
              << " = " << totalFlow << " at index " << resultIndex << std::endl;
    return resultIndex;
}

//==============================================================================
// PRESSURES
//==============================================================================

int createPressureSlot() {
    int index = nextPressIndex++;
    pressureStorage[index] = 101325.0; // Default: 1 atm in Pa
    std::cout << "[C++] Created pressure slot: " << index << std::endl;
    return index;
}

void setPressure(int index, double pressure) {
    pressureStorage[index] = pressure;
    // Commenta se produce troppo output
    // std::cout << "[C++] Set P[" << index << "] = " << pressure << " Pa" << std::endl;
}

double getPressure(int index) {
    if (pressureStorage.find(index) == pressureStorage.end()) {
        std::cerr << "[C++] Error: Pressure index " << index << " not found!" << std::endl;
        return 0.0;
    }
    return pressureStorage[index];
}

int mixPressures(int idx1, int idx2) {
    double press1 = getPressure(idx1);
    double press2 = getPressure(idx2);
    double mixedPress = 0.5 * (press1 + press2);
    
    int resultIndex = createPressureSlot();
    pressureStorage[resultIndex] = mixedPress;
    
    std::cout << "[C++] Mixed pressures: " << press1 << " + " << press2 
              << " = " << mixedPress << " at index " << resultIndex << std::endl;
    return resultIndex;
}

//==============================================================================
// UTILITY
//==============================================================================

void clearAllStorage() {
    temperatureStorage.clear();
    flowRateStorage.clear();
    pressureStorage.clear();
    nextTempIndex = 0;
    nextFlowIndex = 0;
    nextPressIndex = 0;
    std::cout << "[C++] Cleared all storage" << std::endl;
}

void printAllTemperatures() {
    std::cout << "[C++] === TEMPERATURES ===" << std::endl;
    for (const auto& pair : temperatureStorage) {
        std::cout << "  T[" << pair.first << "] = " << pair.second << "°C" << std::endl;
    }
}

void printAllFlowRates() {
    std::cout << "[C++] === FLOW RATES ===" << std::endl;
    for (const auto& pair : flowRateStorage) {
        std::cout << "  m[" << pair.first << "] = " << pair.second << " kg/s" << std::endl;
    }
}

void printAllPressures() {
    std::cout << "[C++] === PRESSURES ===" << std::endl;
    for (const auto& pair : pressureStorage) {
        std::cout << "  P[" << pair.first << "] = " << pair.second/1000.0 << " kPa" << std::endl;
    }
}

void printFluidState(int tempIdx, int flowIdx, int pressIdx) {
    std::cout << "[C++] === FLUID STATE ===" << std::endl;
    std::cout << "  Temperature: T[" << tempIdx << "] = " << getTemperature(tempIdx) << " °C" << std::endl;
    std::cout << "  Flow rate:   m[" << flowIdx << "] = " << getFlowRate(flowIdx) << " kg/s" << std::endl;
    std::cout << "  Pressure:    P[" << pressIdx << "] = " << getPressure(pressIdx)/1000.0 << " kPa" << std::endl;
    std::cout << "[C++] ====================" << std::endl;
}

} // extern "C"
#ifndef FLUID_STORAGE_H
#define FLUID_STORAGE_H

#ifdef __cplusplus
extern "C" {
#endif

//==============================================================================
// GESTIONE TEMPERATURE
//==============================================================================
int createTemperatureSlot();
void setTemperature(int index, double temperature);
double getTemperature(int index);
int mixTemperatures(int idx1, int idx2);

//==============================================================================
// GESTIONE PORTATE
//==============================================================================
int createFlowRateSlot();
void setFlowRate(int index, double flowRate);
double getFlowRate(int index);
int sumFlowRates(int idx1, int idx2);

//==============================================================================
// GESTIONE PRESSIONI
//==============================================================================
int createPressureSlot();
void setPressure(int index, double pressure);
double getPressure(int index);
int mixPressures(int idx1, int idx2);

//==============================================================================
// UTILITY
//==============================================================================
void clearAllStorage();
void printAllTemperatures();
void printAllFlowRates();
void printAllPressures();
void printFluidState(int tempIdx, int flowIdx, int pressIdx);

#ifdef __cplusplus
}
#endif

#endif // FLUID_STORAGE_H
#include "Prova3.h"
#include <map>
#include <string>
#include <vector>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <cmath>

//==============================================================================
// STORAGE GLOBALI
//==============================================================================
static std::map<int, double> temperatureStorage;
static std::map<int, double> flowRateStorage;
static std::map<int, double> pressureStorage;

// Storage per composizioni (usando struttura C++)
struct CompositionData {
    std::vector<std::string> componentNames;
    std::vector<double> concentrations;
};
static std::map<int, CompositionData> compositionStorage;

static int nextTempIndex = 0;
static int nextFlowIndex = 0;
static int nextPressIndex = 0;
static int nextCompIndex = 0;

//==============================================================================
// IMPLEMENTAZIONE FUNZIONI
//==============================================================================

extern "C" {

//------------------------------------------------------------------------------
// TEMPERATURE
//------------------------------------------------------------------------------

int createTemperatureSlot() {
    int index = nextTempIndex++;
    temperatureStorage[index] = 20.0;
    std::cout << "[C++] Created temperature slot: " << index << std::endl;
    return index;
}

void setTemperature(int index, double temperature) {
    temperatureStorage[index] = temperature;
}

double getTemperature(int index) {
    if (temperatureStorage.find(index) == temperatureStorage.end()) {
        std::cerr << "[C++] Error: Temperature index " << index << " not found!" << std::endl;
        return 0.0;
    }
    return temperatureStorage[index];
}

//------------------------------------------------------------------------------
// FLOW RATES
//------------------------------------------------------------------------------

int createFlowRateSlot() {
    int index = nextFlowIndex++;
    flowRateStorage[index] = 0.0;
    std::cout << "[C++] Created flow rate slot: " << index << std::endl;
    return index;
}

void setFlowRate(int index, double flowRate) {
    flowRateStorage[index] = flowRate;
}

double getFlowRate(int index) {
    if (flowRateStorage.find(index) == flowRateStorage.end()) {
        std::cerr << "[C++] Error: Flow rate index " << index << " not found!" << std::endl;
        return 0.0;
    }
    return flowRateStorage[index];
}

//------------------------------------------------------------------------------
// PRESSURES
//------------------------------------------------------------------------------

int createPressureSlot() {
    int index = nextPressIndex++;
    pressureStorage[index] = 101325.0;
    std::cout << "[C++] Created pressure slot: " << index << std::endl;
    return index;
}

void setPressure(int index, double pressure) {
    pressureStorage[index] = pressure;
}

double getPressure(int index) {
    if (pressureStorage.find(index) == pressureStorage.end()) {
        std::cerr << "[C++] Error: Pressure index " << index << " not found!" << std::endl;
        return 0.0;
    }
    return pressureStorage[index];
}

//------------------------------------------------------------------------------
// COMPOSITIONS
//------------------------------------------------------------------------------

int createCompositionSlot() {
    int index = nextCompIndex++;
    compositionStorage[index] = CompositionData();
    std::cout << "[C++] Created composition slot: " << index << std::endl;
    return index;
}

void setComposition(int index, const char** names, const double* concentrations, int nComponents) {
    CompositionData& comp = compositionStorage[index];
    comp.componentNames.clear();
    comp.concentrations.clear();
    
    for (int i = 0; i < nComponents; i++) {
        comp.componentNames.push_back(std::string(names[i]));
        comp.concentrations.push_back(concentrations[i]);
    }
    
    std::cout << "[C++] Set composition[" << index << "] with " << nComponents << " components: ";
    for (int i = 0; i < nComponents; i++) {
        std::cout << names[i] << "=" << concentrations[i];
        if (i < nComponents - 1) std::cout << ", ";
    }
    std::cout << std::endl;
}

int mixCompositions(int idx1, double flowRate1, int idx2, double flowRate2) {
    if (compositionStorage.find(idx1) == compositionStorage.end() ||
        compositionStorage.find(idx2) == compositionStorage.end()) {
        std::cerr << "[C++] Error: Invalid composition indices for mixing!" << std::endl;
        return -1;
    }
    
    CompositionData& comp1 = compositionStorage[idx1];
    CompositionData& comp2 = compositionStorage[idx2];
    
    std::cout << "\n[C++] ========== MIXING COMPOSITIONS ==========" << std::endl;
    std::cout << "[C++] Stream 1 (m=" << flowRate1 << " kg/s): ";
    for (size_t i = 0; i < comp1.componentNames.size(); i++) {
        std::cout << comp1.componentNames[i] << "=" << comp1.concentrations[i] << " ";
    }
    std::cout << std::endl;
    
    std::cout << "[C++] Stream 2 (m=" << flowRate2 << " kg/s): ";
    for (size_t i = 0; i < comp2.componentNames.size(); i++) {
        std::cout << comp2.componentNames[i] << "=" << comp2.concentrations[i] << " ";
    }
    std::cout << std::endl;
    
    // Calcola i pesi
    double totalFlow = flowRate1 + flowRate2;
    double w1, w2;
    
    if (totalFlow < 1e-10) {
        std::cout << "[C++] Note: Total flow rate very small (" << totalFlow 
                  << "), using equal weights (0.5, 0.5)" << std::endl;
        w1 = 0.5;
        w2 = 0.5;
    } else {
        w1 = flowRate1 / totalFlow;
        w2 = flowRate2 / totalFlow;
        std::cout << "[C++] Weights: w1=" << w1 << ", w2=" << w2 << std::endl;
    }
    
    // Usa std::map per unire i componenti automaticamente (ordine alfabetico)
    std::map<std::string, double> mixedComponents;
    
    // Aggiungi componenti dal primo stream (pesati)
    for (size_t i = 0; i < comp1.componentNames.size(); i++) {
        std::string name = comp1.componentNames[i];
        double concentration = comp1.concentrations[i] * w1;
        mixedComponents[name] = concentration;
    }
    
    // Aggiungi/somma componenti dal secondo stream (pesati)
    for (size_t i = 0; i < comp2.componentNames.size(); i++) {
        std::string name = comp2.componentNames[i];
        double concentration = comp2.concentrations[i] * w2;
        
        if (mixedComponents.find(name) != mixedComponents.end()) {
            // Componente già presente: somma le concentrazioni
            mixedComponents[name] += concentration;
        } else {
            // Nuovo componente
            mixedComponents[name] = concentration;
        }
    }
    
    // Crea la nuova composizione miscelata
    int resultIndex = createCompositionSlot();
    CompositionData& resultComp = compositionStorage[resultIndex];
    
    // std::map ordina automaticamente le chiavi alfabeticamente
    for (const auto& pair : mixedComponents) {
        resultComp.componentNames.push_back(pair.first);
        resultComp.concentrations.push_back(pair.second);
    }
    
    std::cout << "[C++] Mixed result (index=" << resultIndex << "): ";
    for (size_t i = 0; i < resultComp.componentNames.size(); i++) {
        std::cout << resultComp.componentNames[i] << "=" 
                  << resultComp.concentrations[i];
        if (i < resultComp.componentNames.size() - 1) std::cout << ", ";
    }
    std::cout << std::endl;
    std::cout << "[C++] =========================================\n" << std::endl;
    
    return resultIndex;
}

int getNumberOfComponents(int index) {
    if (compositionStorage.find(index) == compositionStorage.end()) {
        std::cerr << "[C++] Error: Composition index " << index << " not found!" << std::endl;
        return 0;
    }
    
    CompositionData& comp = compositionStorage[index];
    return comp.componentNames.size();
}

double getComponentConcentration(int index, int componentIdx) {
    if (compositionStorage.find(index) == compositionStorage.end()) {
        std::cerr << "[C++] Error: Composition index " << index << " not found!" << std::endl;
        return 0.0;
    }
    
    CompositionData& comp = compositionStorage[index];
    
    if (componentIdx < 0 || componentIdx >= (int)comp.concentrations.size()) {
        std::cerr << "[C++] Error: Component index " << componentIdx 
                  << " out of range (0-" << comp.concentrations.size()-1 
                  << ") for composition " << index << std::endl;
        return 0.0;
    }
    
    return comp.concentrations[componentIdx];
}

double getComponentConcentrationByName(int index, const char* componentName) {
    if (compositionStorage.find(index) == compositionStorage.end()) {
        std::cerr << "[C++] Error: Composition index " << index << " not found!" << std::endl;
        return 0.0;
    }
    
    CompositionData& comp = compositionStorage[index];
    std::string searchName(componentName);
    
    // Cerca il componente per nome
    for (size_t i = 0; i < comp.componentNames.size(); i++) {
        if (comp.componentNames[i] == searchName) {
            return comp.concentrations[i];
        }
    }
    
    // Componente non trovato - ritorna 0 (non è un errore, è normale)
    return 0.0;
}

int hasComponent(int index, const char* componentName) {
    if (compositionStorage.find(index) == compositionStorage.end()) {
        return 0;  // false
    }
    
    CompositionData& comp = compositionStorage[index];
    std::string searchName(componentName);
    
    for (size_t i = 0; i < comp.componentNames.size(); i++) {
        if (comp.componentNames[i] == searchName) {
            return 1;  // true
        }
    }
    
    return 0;  // false
}

void printComposition(int index) {
    if (compositionStorage.find(index) == compositionStorage.end()) {
        std::cout << "[C++] Composition[" << index << "]: <not found>" << std::endl;
        return;
    }
    
    CompositionData& comp = compositionStorage[index];
    std::cout << "[C++] Composition[" << index << "]:" << std::endl;
    for (size_t i = 0; i < comp.componentNames.size(); i++) {
        std::cout << "  " << comp.componentNames[i] << " = " 
                  << comp.concentrations[i] << " mol/m³" << std::endl;
    }
}

void printCompositionCompact(int index) {
    if (compositionStorage.find(index) == compositionStorage.end()) {
        std::cout << "[C++] Comp[" << index << "]: <empty>" << std::endl;
        return;
    }
    
    CompositionData& comp = compositionStorage[index];
    std::cout << "[C++] Comp[" << index << "] (" << comp.componentNames.size() << " components): ";
    
    for (size_t i = 0; i < comp.componentNames.size(); i++) {
        std::cout << comp.componentNames[i] << "=" << comp.concentrations[i];
        if (i < comp.componentNames.size() - 1) {
            std::cout << ", ";
        }
    }
    std::cout << std::endl;
}

void freeComposition(int index) {
    compositionStorage.erase(index);
}

//------------------------------------------------------------------------------
// UTILITY
//------------------------------------------------------------------------------

void clearAllStorage() {
    temperatureStorage.clear();
    flowRateStorage.clear();
    pressureStorage.clear();
    compositionStorage.clear();
    nextTempIndex = 0;
    nextFlowIndex = 0;
    nextPressIndex = 0;
    nextCompIndex = 0;
    std::cout << "[C++] Cleared all storage" << std::endl;
}

void printAllTemperatures() {
    std::cout << "[C++] === TEMPERATURES ===" << std::endl;
    for (const auto& pair : temperatureStorage) {
        std::cout << "  T[" << pair.first << "] = " << pair.second << "°C" << std::endl;
    }
}

void printAllFlowRates() {
    std::cout << "[C++] === FLOW RATES ===" << std::endl;
    for (const auto& pair : flowRateStorage) {
        std::cout << "  m[" << pair.first << "] = " << pair.second << " kg/s" << std::endl;
    }
}

void printAllPressures() {
    std::cout << "[C++] === PRESSURES ===" << std::endl;
    for (const auto& pair : pressureStorage) {
        std::cout << "  P[" << pair.first << "] = " << pair.second/1000.0 << " kPa" << std::endl;
    }
}

void printAllCompositions() {
    std::cout << "[C++] === COMPOSITIONS ===" << std::endl;
    for (const auto& pair : compositionStorage) {
        std::cout << "  Comp[" << pair.first << "]: ";
        const CompositionData& comp = pair.second;
        for (size_t i = 0; i < comp.componentNames.size(); i++) {
            std::cout << comp.componentNames[i] << "=" << comp.concentrations[i];
            if (i < comp.componentNames.size() - 1) std::cout << ", ";
        }
        std::cout << std::endl;
    }
}

void printFluidState(int tempIdx, int flowIdx, int pressIdx) {
    std::cout << "[C++] === FLUID STATE ===" << std::endl;
    std::cout << "  Temperature: T[" << tempIdx << "] = " << getTemperature(tempIdx) << " °C" << std::endl;
    std::cout << "  Flow rate:   m[" << flowIdx << "] = " << getFlowRate(flowIdx) << " kg/s" << std::endl;
    std::cout << "  Pressure:    P[" << pressIdx << "] = " << getPressure(pressIdx)/1000.0 << " kPa" << std::endl;
    std::cout << "[C++] ====================" << std::endl;
}

} // extern "C"